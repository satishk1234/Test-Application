var mongoose = require('mongoose');
Ticket = mongoose.model('Ticket');
const jwt = require("jsonwebtoken");
var logger = require("../shared/lib/logger");
const moment = require("moment");
const e = require('express');
exports.create = function (req, res) {
    var theTicket = new Ticket(req.body);
    theTicket.save(function (err) {
        if (err) {
            console.log(err);
        } else {
  
            res.send(theTicket);
        }
    });
};

exports.all = function (req, res) {
    Ticket.find({}).exec(function (err, data) {
        if (err) {
            res.failure(err)
        } else {
            res.json(data);
        }
    })
}

exports.show = function(req, res) {
    Ticket.findOne({ _id: req.params.id }).exec(function (err, data) {
        if (err) {
            res.failure(err)
        } else {
            res.json(data);
        }
    })
}

exports.destroy = function (req, res) {
    var sid = req.params.id;
    Ticket.findById(sid, function (err, doc) {
        doc.remove(function () {
            res.json({ message: "deleted" });
        })
    })
}

exports.update = function (req, res) {
    var sid = req.body._id;
    Ticket.findById(sid, function (err, doc) {
         doc.name = req.body.name;
         doc.moviename = req.body.moviename;
         doc.booking_date = req.body.booking_date;
         doc.time = req.body.time;
         doc.price = req.body.price;
       doc.save(function () {
            res.json(doc);
        })
    })
}

exports.datewisesummaryprofitTickets = function(req, res) {
      Ticket.find({ 
        booking_date: {
            $gte: req.body.fromdate,
            $lte: req.body.todate
        }
    
    }).exec(function (err, data) {
        if (err) {
            res.failure(err)
        } else {
    if(req.body.fromdate <= req.body.todate){        
    var weekDay =  moment().format('dddd');
        var obj = {}
            var total = 0;
       for (var i = 0; i < data.length; i++) {
              total = total + Number(data[i].price);
            }
   
    obj.Month= weekDay;
    obj.summaryProfit= total;

    // res.json(obj);
    res.send({
        status: 200,
        error: false,
        message: "Movie summary profit is fetch successfully.",
        data:obj
      });
    }
    else{
        res.send({
            status: 204,
            error: true,
            message: "Please check between date range! Given to proper date range",
          });
    }
    }
    })
}

exports.datewisesummaryVisitsTickets  = function(req, res) {
    Ticket.find({ 
      booking_date: {
          $gte: req.body.fromdate,
          $lte: req.body.todate
      }  
  }).exec(function (err, data) {
      if (err) {
          res.failure(err)
      } else {
var weekDay =  moment().format('dddd');
      var obj = {}
      
 if(req.body.fromdate <= req.body.todate)
 {
    obj.Month= weekDay;
    obj.summaryVisits= data.length;  
    // res.json(obj);
    res.send({
        status: 200,
        error: false,
        message: "Movie summary profit is fetch successfully.",
        data:obj
      });
}
else{
    res.send({
        status: 204,
        error: true,
        message: "Please check between date range! Given to proper date range",
      });
}
  
  }
  })
}