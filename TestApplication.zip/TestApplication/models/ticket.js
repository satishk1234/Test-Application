const { Timestamp } = require('mongodb');

var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    crypto = require('crypto');

var TicketSchema = new Schema({
    name: String,
    moviename: String,
    booking_date:String,
    time:String,
    price:String
});



mongoose.model('Ticket', TicketSchema);
