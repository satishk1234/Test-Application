var express = require("express");

var router = express.Router();
module.exports = function(app, passport) {
//user routes
var users = require('../controllers/users');
const VerifyToken = require('../config/verifyToken');
router.post("/api/registerUser",users.create);
router.get("/api/listusers", VerifyToken, users.all);
router.get("/api/editUser/:id", VerifyToken, users.show);
router.put("/api/updateUser", VerifyToken,users.update);
router.delete("/api/deleteUser/:id", VerifyToken, users.destroy);

//Tickets routes
var Tickets = require('../controllers/Tickets');
router.post("/api/ticketBooking", VerifyToken, Tickets.create);
router.get("/api/listTickets", VerifyToken, Tickets.all);
router.get("/api/editTicket/:id", VerifyToken, Tickets.show);
router.put("/api/updaTeTicket", VerifyToken, Tickets.update);
router.post("/api/datewisesummaryprofitTickets", VerifyToken, Tickets.datewisesummaryprofitTickets);
router.post("/api/datewisesummaryVisitsTickets", VerifyToken, Tickets.datewisesummaryVisitsTickets);
router.delete("/api/deleteTicket/:id", VerifyToken, Tickets.destroy);
return router;

}