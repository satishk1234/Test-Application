var jwt = require("jsonwebtoken");
var dbConfig = require("../config/config");
const moment = require("moment");
function verifyToken(req, res, next) {
	try {
	  const token = req.headers.authorization;
	  const decoded = jwt.verify(token, dbConfig.SECRET);
	  next();
	} catch (error) {
	  res.status(401).json({ message: "Authentication Failure !!" });
	}
  }
  module.exports = verifyToken;
